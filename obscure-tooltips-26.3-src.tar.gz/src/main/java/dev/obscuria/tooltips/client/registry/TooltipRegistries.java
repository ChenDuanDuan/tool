package dev.obscuria.tooltips.client.registry;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import dev.obscuria.tooltips.client.tooltip.TooltipDefinition;
import dev.obscuria.tooltips.client.tooltip.TooltipLabel;
import dev.obscuria.tooltips.client.tooltip.TooltipStyle;
import dev.obscuria.tooltips.client.tooltip.element.effect.TooltipEffect;
import dev.obscuria.tooltips.client.tooltip.element.frame.TooltipFrame;
import dev.obscuria.tooltips.client.tooltip.element.icon.TooltipIcon;
import dev.obscuria.tooltips.client.tooltip.element.panel.TooltipPanel;
import dev.obscuria.tooltips.client.tooltip.element.slot.TooltipSlot;
import dev.obscuria.tooltips.client.tooltip.filter.ItemFilter;
import dev.obscuria.tooltips.client.tooltip.label.LabelProvider;
import dev.obscuria.tooltips.client.tooltip.layout.TooltipLayout;
import dev.obscuria.tooltips.client.tooltip.particle.TooltipParticle;

import java.util.Map;

/**
 * Registry layer rebuilt on plain maps instead of Fragmentum's game registries.
 * <p>
 * Each element interface owns a {@code Map<String, MapCodec<? extends T>>} plus a
 * {@code bootstrapTypes()} method that fills it. Java forbids static initialiser
 * blocks in interfaces, so {@link #init()} is the single place that drives every
 * element type list; the tables are exposed here so the shared dispatch codec in
 * {@link TypeDispatch} can resolve the inline "type" field.
 */
public interface TooltipRegistries {

    interface Types {

        Map<String, MapCodec<? extends ItemFilter>> ITEM_FILTER = ItemFilter.TYPES;
        Map<String, MapCodec<? extends LabelProvider>> LABEL_PROVIDER = LabelProvider.TYPES;
        Map<String, MapCodec<? extends TooltipParticle>> TOOLTIP_PARTICLE = TooltipParticle.TYPES;
        Map<String, MapCodec<? extends TooltipPanel>> TOOLTIP_PANEL = TooltipPanel.TYPES;
        Map<String, MapCodec<? extends TooltipFrame>> TOOLTIP_FRAME = TooltipFrame.TYPES;
        Map<String, MapCodec<? extends TooltipSlot>> TOOLTIP_SLOT = TooltipSlot.TYPES;
        Map<String, MapCodec<? extends TooltipIcon>> TOOLTIP_ICON = TooltipIcon.TYPES;
        Map<String, MapCodec<? extends TooltipEffect>> TOOLTIP_EFFECT = TooltipEffect.TYPES;
        Map<String, MapCodec<? extends TooltipLayout<?>>> TOOLTIP_LAYOUT = TooltipLayout.TYPES;
    }

    interface Resource {

        ResourceRegistry<TooltipPanel> TOOLTIP_PANEL = new ResourceRegistry<>("panel");
        ResourceRegistry<TooltipFrame> TOOLTIP_FRAME = new ResourceRegistry<>("frame");
        ResourceRegistry<TooltipSlot> TOOLTIP_SLOT = new ResourceRegistry<>("slot");
        ResourceRegistry<TooltipIcon> TOOLTIP_ICON = new ResourceRegistry<>("icon");
        ResourceRegistry<TooltipEffect> TOOLTIP_EFFECT = new ResourceRegistry<>("effect");
        ResourceRegistry<TooltipStyle> TOOLTIP_STYLE = new ResourceRegistry<>("style");
        ResourceRegistry<TooltipDefinition> TOOLTIP_DEFINITION = new ResourceRegistry.Ordered<>("definition");
        ResourceRegistry<TooltipLabel> TOOLTIP_LABEL = new ResourceRegistry.Ordered<>("label");
    }

    static Codec<ItemFilter> itemFilterCodec() {
        return TypeDispatch.deferred(Types.ITEM_FILTER);
    }

    static Codec<LabelProvider> labelProviderCodec() {
        return TypeDispatch.deferred(Types.LABEL_PROVIDER);
    }

    static Codec<TooltipParticle> tooltipParticleCodec() {
        return TypeDispatch.deferred(Types.TOOLTIP_PARTICLE);
    }

    static Codec<TooltipPanel> tooltipPanelCodec() {
        return TypeDispatch.deferred(Types.TOOLTIP_PANEL);
    }

    static Codec<TooltipFrame> tooltipFrameCodec() {
        return TypeDispatch.deferred(Types.TOOLTIP_FRAME);
    }

    static Codec<TooltipSlot> tooltipSlotCodec() {
        return TypeDispatch.deferred(Types.TOOLTIP_SLOT);
    }

    static Codec<TooltipIcon> tooltipIconCodec() {
        return TypeDispatch.deferred(Types.TOOLTIP_ICON);
    }

    static Codec<TooltipEffect> tooltipEffectCodec() {
        return TypeDispatch.deferred(Types.TOOLTIP_EFFECT);
    }

    static void init() {
        // Interfaces cannot use static initialiser blocks, so populate every
        // element type table explicitly here, before any codec is resolved.
        ItemFilter.bootstrapTypes();
        LabelProvider.bootstrapTypes();
        TooltipParticle.bootstrapTypes();
        TooltipPanel.bootstrapTypes();
        TooltipFrame.bootstrapTypes();
        TooltipSlot.bootstrapTypes();
        TooltipIcon.bootstrapTypes();
        TooltipEffect.bootstrapTypes();
        TooltipLayout.bootstrapTypes();
    }
}
