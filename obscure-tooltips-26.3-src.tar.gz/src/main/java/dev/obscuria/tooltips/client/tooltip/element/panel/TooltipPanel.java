package dev.obscuria.tooltips.client.tooltip.element.panel;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import dev.obscuria.tooltips.client.registry.TooltipRegistries;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import java.util.Map;

public interface TooltipPanel {

    Map<String, MapCodec<? extends TooltipPanel>> TYPES = new java.util.LinkedHashMap<>();

    Codec<TooltipPanel> DIRECT_CODEC = TooltipRegistries.tooltipPanelCodec();
    Codec<TooltipPanel> CODEC = TooltipRegistries.Resource.TOOLTIP_PANEL.byNameCodec();

    MapCodec<? extends TooltipPanel> codec();

    void render(GuiGraphicsExtractor graphics, int x, int y, int width, int height);

    static void bootstrapTypes() {
        TYPES.put("blank", BlankPanel.CODEC);
        TYPES.put("color_rect", ColorRectPanel.CODEC);
    }

}
