package dev.obscuria.tooltips.client.tooltip.particle;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import dev.obscuria.tooltips.client.ParticleData;
import dev.obscuria.tooltips.client.TooltipState;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import java.util.Map;

public interface TooltipParticle {

    Map<String, MapCodec<? extends TooltipParticle>> TYPES = new java.util.LinkedHashMap<>();

    Codec<TooltipParticle> CODEC = dev.obscuria.tooltips.client.registry.TooltipRegistries.tooltipParticleCodec();

    MapCodec<? extends TooltipParticle> codec();

    void render(GuiGraphicsExtractor graphics, TooltipState state, ParticleData data);

    static void bootstrapTypes() {
        TYPES.put("texture", TextureParticle.CODEC);
        TYPES.put("line", LineParticle.CODEC);
    }

}
