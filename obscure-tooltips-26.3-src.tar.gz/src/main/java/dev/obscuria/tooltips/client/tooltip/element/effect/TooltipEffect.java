package dev.obscuria.tooltips.client.tooltip.element.effect;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import dev.obscuria.tooltips.client.registry.TooltipRegistries;
import dev.obscuria.tooltips.client.TooltipState;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import java.util.List;
import java.util.Map;

public interface TooltipEffect {

    Map<String, MapCodec<? extends TooltipEffect>> TYPES = new java.util.LinkedHashMap<>();

    Codec<TooltipEffect> DIRECT_CODEC = TooltipRegistries.tooltipEffectCodec();
    Codec<TooltipEffect> CODEC = TooltipRegistries.Resource.TOOLTIP_EFFECT.byNameCodec();

    MapCodec<? extends TooltipEffect> codec();

    boolean canApply(List<TooltipEffect> effects);

    default void renderIcon(TooltipState state, GuiGraphicsExtractor graphics, int x, int y) {}

    default void renderBack(TooltipState state, GuiGraphicsExtractor graphics, int x, int y, int width, int height) {}

    default void renderFront(TooltipState state, GuiGraphicsExtractor graphics, int x, int y, int width, int height) {}

    static void bootstrapTypes() {
        TYPES.put("rim_light", RimLightEffect.CODEC);
        TYPES.put("ray_glow", RayGlowEffect.CODEC);
        TYPES.put("inward_particle", InwardParticleEffect.CODEC);
        TYPES.put("icon_particle", IconParticleEffect.CODEC);
        TYPES.put("shimmer", ShimmerEffect.CODEC);
    }

}
