package dev.obscuria.tooltips.client.registry;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import net.minecraft.util.ExtraCodecs;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;

/**
 * Builds the "type" dispatching codec shared by every polymorphic tooltip element.
 * <p>
 * Each element interface exposes a {@code TYPES} map plus a {@code bootstrapTypes()}
 * method. Interface constants are initialised before {@code bootstrapTypes()} runs,
 * so {@link #of} must not be evaluated during class initialisation. Use
 * {@link #deferred} for constants: it resolves the dispatch codec on first real use,
 * by which point {@code TooltipRegistries.init()} has populated every table.
 */
public final class TypeDispatch {

    private TypeDispatch() {}

    public static <T> Map<String, MapCodec<? extends T>> newMap() {
        return new LinkedHashMap<>();
    }

    /**
     * Vanilla pattern: an inline "type" string resolves to an {@code IdMapper} entry,
     * whose codec then decodes the rest of the object.
     * <p>
     * Call this only after the type table has been bootstrapped.
     */
    public static <T> Codec<T> of(Map<String, MapCodec<? extends T>> types) {
        final var mapper = ExtraCodecs.lateBoundIdMapper();
        types.forEach(mapper::put);
        return mapper.codec(MapCodec::codec)
                .dispatch(value -> value.codec(), MapCodec::codec);
    }

    /**
     * Returns a codec backed by {@code types} that builds the dispatch table on the
     * first encode/decode call. Safe to assign to an interface constant.
     */
    public static <T> Codec<T> deferred(Map<String, MapCodec<? extends T>> types) {
        final var holder = new Holder<T>();
        holder.supplier = () -> of(types);
        return holder;
    }

    private static final class Holder<T> implements Codec<T> {

        private Supplier<Codec<T>> supplier;
        private volatile Codec<T> delegate;

        private Codec<T> resolve() {
            Codec<T> local = delegate;
            if (local == null) {
                synchronized (this) {
                    local = delegate;
                    if (local == null) {
                        local = supplier.get();
                        delegate = local;
                    }
                }
            }
            return local;
        }

        @Override
        public <B> com.mojang.serialization.DataResult<com.mojang.serialization.Encoder<B>> encode(
                T input,
                com.mojang.serialization.DynamicOps<B> ops,
                com.mojang.serialization.RecordBuilder<B> prefix) {
            return resolve().encode(input, ops, prefix);
        }

        @Override
        public <B> com.mojang.serialization.DataResult<T> decode(
                com.mojang.serialization.DynamicOps<B> ops,
                com.mojang.serialization.MapLike<B> input) {
            return resolve().decode(ops, input);
        }

        @Override
        public <B> com.mojang.serialization.DataResult<B> encode(
                T input,
                com.mojang.serialization.DynamicOps<B> ops,
                B prefix) {
            return resolve().encode(input, ops, prefix);
        }

        @Override
        public <B> com.mojang.serialization.DataResult<T> parse(
                com.mojang.serialization.DynamicOps<B> ops,
                B input) {
            return resolve().parse(ops, input);
        }
    }
}
