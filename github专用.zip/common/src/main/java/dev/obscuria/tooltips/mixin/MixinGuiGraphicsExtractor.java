package dev.obscuria.tooltips.mixin;

import dev.obscuria.tooltips.client.TooltipRenderer;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.tooltip.ClientTooltipComponent;
import net.minecraft.client.gui.screens.inventory.tooltip.ClientTooltipPositioner;
import net.minecraft.resources.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

/**
 * 1.20.1/1.21.x injected {@code GuiGraphics#renderTooltipInternal}.
 * In 26.3 that class is gone: tooltips are built by {@code GuiGraphicsExtractor}
 * and committed through {@code setTooltipForNextFrameInternal}.
 */
@Mixin(GuiGraphicsExtractor.class)
public abstract class MixinGuiGraphicsExtractor {

    @Inject(
            method = "setTooltipForNextFrameInternal(Lnet/minecraft/client/gui/Font;Ljava/util/List;IILnet/minecraft/client/gui/screens/inventory/tooltip/ClientTooltipPositioner;Lnet/minecraft/resources/Identifier;ZZ)V",
            at = @At("HEAD"),
            cancellable = true
    )
    private void obscure_tooltips$renderCustomTooltip(
            Font font, List<ClientTooltipComponent> components, int mouseX, int mouseY,
            ClientTooltipPositioner positioner, Identifier style, boolean isFirstTooltip, boolean extraSpace,
            CallbackInfo info) {

        final var self = (GuiGraphicsExtractor) (Object) this;
        if (TooltipRenderer.render(self, font, components, mouseX, mouseY, positioner)) info.cancel();
    }
}
