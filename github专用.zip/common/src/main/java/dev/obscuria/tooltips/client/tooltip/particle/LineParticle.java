package dev.obscuria.tooltips.client.tooltip.particle;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.obscuria.tooltips.client.ParticleData;
import dev.obscuria.tooltips.client.TooltipState;
import dev.obscuria.tooltips.client.color.Argb;
import dev.obscuria.tooltips.client.tooltip.element.Transform;
import net.minecraft.client.gui.GuiGraphicsExtractor;

public record LineParticle(
        Argb centerColor,
        Argb edgeColor,
        Transform transform
) implements TooltipParticle {

    public static final MapCodec<LineParticle> CODEC;

    @Override
    public MapCodec<LineParticle> codec() {
        return CODEC;
    }

    @Override
    public void render(GuiGraphicsExtractor graphics, TooltipState state, ParticleData data) {
        final var pose = graphics.pose();
        pose.pushMatrix();
        transform.apply(graphics);
        pose.translate(0f, -0.5f);
        GraphicUtils.drawHLineOverlay(graphics, -8, 0, 8, edgeColor, centerColor);
        GraphicUtils.drawHLineOverlay(graphics, 0, 0, 8, centerColor, edgeColor);
        pose.popMatrix();
    }

    static {
        CODEC = RecordCodecBuilder.mapCodec(codec -> codec.group(
                Argb.CODEC.fieldOf("center_color").forGetter(LineParticle::centerColor),
                Argb.CODEC.fieldOf("edge_color").forGetter(LineParticle::edgeColor),
                Transform.CODEC.optionalFieldOf("transform", Transform.DEFAULT).forGetter(LineParticle::transform)
        ).apply(codec, LineParticle::new));
    }
}
