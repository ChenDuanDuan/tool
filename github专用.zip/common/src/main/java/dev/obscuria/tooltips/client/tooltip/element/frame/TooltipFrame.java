package dev.obscuria.tooltips.client.tooltip.element.frame;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import dev.obscuria.tooltips.client.registry.TooltipRegistries;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import java.util.Map;

public interface TooltipFrame {

    Map<String, MapCodec<? extends TooltipFrame>> TYPES = new java.util.LinkedHashMap<>();

    Codec<TooltipFrame> DIRECT_CODEC = TooltipRegistries.tooltipFrameCodec();
    Codec<TooltipFrame> CODEC = TooltipRegistries.Resource.TOOLTIP_FRAME.byNameCodec();

    MapCodec<? extends TooltipFrame> codec();

    void render(GuiGraphicsExtractor graphics, int x, int y, int width, int height);

    static void bootstrapTypes() {
        TYPES.put("blank", BlankFrame.CODEC);
        TYPES.put("nine_sliced", NineSlicedFrame.CODEC);
    }

    static {
        bootstrapTypes();
    }
}
