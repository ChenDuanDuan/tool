package dev.obscuria.tooltips.client.color;

import net.minecraft.world.item.ItemStack;

/**
 * Static palette helpers extracted from Fragmentum's Colors class.
 */
public final class Colors {

    private Colors() {}

    public static Argb argbOf(int argb) {
        return new Argb(argb);
    }

    public static Argb argbOf(float red, float green, float blue, float alpha) {
        return Argb.of(red, green, blue, alpha);
    }

    public static Argb rgbOf(int rgb) {
        return Argb.rgb(rgb);
    }

    /** Item rarity tint, used as the fallback accent colour for labels. */
    public static Argb rarityColor(ItemStack stack) {
        final var rarity = stack.getRarity();
        final var color = rarity.color();
        return new Argb(0xFF000000 | color.getValue());
    }
}
