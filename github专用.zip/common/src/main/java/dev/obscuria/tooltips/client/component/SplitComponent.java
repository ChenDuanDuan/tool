package dev.obscuria.tooltips.client.component;

import dev.obscuria.tooltips.client.TooltipHelper;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.tooltip.ClientTooltipComponent;

import java.util.List;

public record SplitComponent(
        ClientTooltipComponent left,
        List<ClientTooltipComponent> right
) implements ClientTooltipComponent {

    @Override
    public int getHeight() {
        return Math.max(left.getHeight(), TooltipHelper.heightOf(right));
    }

    @Override
    public int getWidth(Font font) {
        return left.getWidth(font) + 3 + TooltipHelper.widthOf(right, font);
    }

    @Override
    public void extractImage(Font font, int x, int y, int width, int height, GuiGraphicsExtractor graphics) {

        var componentX = x + left.getWidth(font) + 3;
        var componentY = y;
        for (var component : right) {
            component.extractImage(font, componentX, componentY,
                    component.getWidth(font), component.getHeight(), graphics);
            componentY += component.getHeight();
        }

        left.extractImage(font, x, y, left.getWidth(font), left.getHeight(), graphics);
    }

    @Override
    public void extractText(GuiGraphicsExtractor graphics, Font font, int x, int y) {

        var componentX = x + left.getWidth(font) + 3;
        var componentY = y;
        for (var component : right) {
            component.extractText(graphics, font, componentX, componentY);
            componentY += component.getHeight();
        }

        left.extractText(graphics, font, x, y);
    }
}
