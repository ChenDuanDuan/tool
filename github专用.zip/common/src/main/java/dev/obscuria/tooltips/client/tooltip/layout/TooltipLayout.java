package dev.obscuria.tooltips.client.tooltip.layout;

import com.mojang.serialization.MapCodec;
import dev.obscuria.tooltips.client.TooltipState;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.screens.inventory.tooltip.ClientTooltipComponent;
import net.minecraft.world.item.ItemStack;

import java.util.List;
import java.util.Map;

public interface TooltipLayout<T extends TooltipState> {

    Map<String, MapCodec<? extends TooltipLayout<?>>> TYPES = new java.util.LinkedHashMap<>();

    MapCodec<? extends TooltipLayout<?>> codec();

    T extractState(ItemStack stack);

    List<ClientTooltipComponent> processPreWrap(T state, List<ClientTooltipComponent> components, Font font);

    List<ClientTooltipComponent> processPostWrap(T state, List<ClientTooltipComponent> components, Font font);

    default List<ClientTooltipComponent> rawProcessPreWrap(TooltipState state, List<ClientTooltipComponent> components, Font font) {
        return processPreWrap(this.adapt(state), components, font);
    }

    default List<ClientTooltipComponent> rawProcessPostWrap(TooltipState state, List<ClientTooltipComponent> components, Font font) {
        return processPostWrap(this.adapt(state), components, font);
    }

    @SuppressWarnings("unchecked")
    default T adapt(TooltipState state) {
        return (T) state;
    }

    static void bootstrapTypes() {
        TYPES.put("default", DefaultLayout.CODEC);
        TYPES.put("armor_preview", ArmorPreviewLayout.CODEC);
        TYPES.put("tool_preview", ToolPreviewLayout.CODEC);
    }

    static {
        bootstrapTypes();
    }
}
