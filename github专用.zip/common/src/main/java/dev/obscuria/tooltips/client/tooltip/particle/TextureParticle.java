package dev.obscuria.tooltips.client.tooltip.particle;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.obscuria.tooltips.client.ParticleData;
import dev.obscuria.tooltips.client.TooltipState;
import dev.obscuria.tooltips.client.tooltip.element.Transform;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;

public record TextureParticle(
        Identifier texture,
        Transform transform
) implements TooltipParticle {

    public static final MapCodec<TextureParticle> CODEC;

    @Override
    public MapCodec<TextureParticle> codec() {
        return CODEC;
    }

    @Override
    public void render(GuiGraphicsExtractor graphics, TooltipState state, ParticleData data) {
        final var pose = graphics.pose();
        pose.pushMatrix();
        transform.apply(graphics);
        graphics.blit(GraphicUtils.texturedPipeline(), texture, -8, -8, 0f, 0f, 16, 16, 16, 16);
        pose.popMatrix();
    }

    static {
        CODEC = RecordCodecBuilder.mapCodec(codec -> codec.group(
                Identifier.CODEC.fieldOf("texture").forGetter(TextureParticle::texture),
                Transform.CODEC.optionalFieldOf("transform", Transform.DEFAULT).forGetter(TextureParticle::transform)
        ).apply(codec, TextureParticle::new));
    }
}
