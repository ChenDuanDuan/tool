package dev.obscuria.tooltips.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import dev.obscuria.tooltips.client.component.StackBuffer;
import dev.obscuria.tooltips.config.ClientConfig;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.inventory.tooltip.TooltipComponent;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.util.Optional;

/**
 * Injects the {@link StackBuffer} marker component so the renderer can recover
 * the {@code ItemStack} being hovered.
 * <p>
 * Fragmentum's {@code GroupTooltip} wrapper is gone: vanilla already accepts a
 * custom {@code TooltipComponent} here, so the buffer is returned directly and
 * {@code TooltipRenderer} looks it up in the component list.
 */
@Mixin(value = ItemStack.class, priority = Integer.MAX_VALUE)
@SuppressWarnings("OptionalUsedAsFieldOrParameterType")
public abstract class MixinItemStack {

    @ModifyReturnValue(method = "getTooltipImage", at = @At("RETURN"))
    private Optional<TooltipComponent> obscure_tooltips$injectBuffer(Optional<TooltipComponent> original) {
        final var self = (ItemStack) (Object) this;
        if (!ClientConfig.ENABLED.get()) return original;
        if (self.has(DataComponents.HIDE_TOOLTIP)) return original;
        if (ClientConfig.isIgnored(self.getItem())) return original;
        return Optional.of(new StackBuffer(self));
    }
}
