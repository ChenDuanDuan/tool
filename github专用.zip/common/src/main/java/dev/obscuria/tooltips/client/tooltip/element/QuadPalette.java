package dev.obscuria.tooltips.client.tooltip.element;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.obscuria.tooltips.client.color.Argb;

public record QuadPalette(
        Argb topLeft,
        Argb topRight,
        Argb bottomLeft,
        Argb bottomRight) {

    public static final Codec<QuadPalette> CODEC = RecordCodecBuilder.create(codec -> codec.group(
            Argb.CODEC.fieldOf("top_left").forGetter(QuadPalette::topLeft),
            Argb.CODEC.fieldOf("top_right").forGetter(QuadPalette::topRight),
            Argb.CODEC.fieldOf("bottom_left").forGetter(QuadPalette::bottomLeft),
            Argb.CODEC.fieldOf("bottom_right").forGetter(QuadPalette::bottomRight)
    ).apply(codec, QuadPalette::new));
}
