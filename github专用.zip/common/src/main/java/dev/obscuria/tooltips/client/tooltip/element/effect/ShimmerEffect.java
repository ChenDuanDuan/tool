package dev.obscuria.tooltips.client.tooltip.element.effect;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.obscuria.tooltips.ObscureTooltips;
import dev.obscuria.tooltips.client.TooltipState;
import dev.obscuria.tooltips.client.color.Argb;
import dev.obscuria.tooltips.client.render.MeshRenderState;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;
import org.joml.Vector2f;

import java.util.List;
import java.util.function.IntConsumer;

/**
 * Animated border shimmer.
 * <p>
 * Geometry is unchanged from 1.21.1 (a segmented ring around the panel edge);
 * only the submission path changed. Instead of writing into a
 * {@code VertexConsumer} obtained from {@code RenderType.guiOverlay()}, the quads
 * are collected into a {@link MeshRenderState} and queued with
 * {@code addGuiElement}.
 */
public record ShimmerEffect(
        Argb innerColor,
        Argb accentColor,
        Argb outerColor,
        float frequency,
        float speed
) implements TooltipEffect {

    public static final Identifier TEXTURE;
    public static final MapCodec<ShimmerEffect> CODEC;

    @Override
    public MapCodec<ShimmerEffect> codec() {
        return CODEC;
    }

    @Override
    public boolean canApply(List<TooltipEffect> effects) {
        return effects.stream().noneMatch(it -> it instanceof ShimmerEffect);
    }

    @Override
    public void renderBack(TooltipState state, GuiGraphicsExtractor graphics, int x, int y, int width, int height) {

        final var actX = x - 3;
        final var actY = y - 3;
        final var actWidth = width + 6;
        final var actHeight = height + 6;

        final var ctrlWidth = actWidth - 24f;
        final var ctrlHeight = actHeight - 24f;
        final var ctrlLeft = actX + 12f;
        final var ctrlTop = actY + 12f;
        final var ctrlRight = ctrlLeft + ctrlWidth;
        final var ctrlBottom = ctrlTop + ctrlHeight;
        final var ctrlCenter = new Vector2f(ctrlLeft + ctrlWidth * 0.5f, ctrlTop + ctrlHeight * 0.5f);

        final var wSegments = 32;
        final var hSegments = Math.max(1, (int) (wSegments * ((float) actHeight / (float) actWidth)));

        final var time = state.timeInSeconds();
        final var builder = MeshRenderState.builder(RenderPipelines.GUI_TEXTURED_PREMULTIPLIED_ALPHA,
                graphics.pose());

        final var inner1 = new Vector2f();
        final var inner2 = new Vector2f();
        final var outer1 = new Vector2f();
        final var outer2 = new Vector2f();

        // Top edge.
        renderSide(builder, wSegments,
                i -> inner1.set(actX + (float) actWidth * i / wSegments, actY),
                i -> inner2.set(actX + (float) actWidth * (i + 1) / wSegments, actY),
                i -> outer1.set(ctrlLeft + ctrlWidth * i / wSegments, ctrlTop),
                i -> outer2.set(ctrlLeft + ctrlWidth * (i + 1) / wSegments, ctrlTop),
                false, ctrlCenter, time, inner1, inner2, outer1, outer2);

        // Bottom edge.
        renderSide(builder, wSegments,
                i -> inner1.set(actX + (float) actWidth * (i + 1) / wSegments, actY + actHeight),
                i -> inner2.set(actX + (float) actWidth * i / wSegments, actY + actHeight),
                i -> outer1.set(ctrlLeft + ctrlWidth * (i + 1) / wSegments, ctrlBottom),
                i -> outer2.set(ctrlLeft + ctrlWidth * i / wSegments, ctrlBottom),
                false, ctrlCenter, time, inner1, inner2, outer1, outer2);

        // Left edge.
        renderSide(builder, hSegments,
                i -> inner1.set(actX, actY + (float) actHeight * i / hSegments),
                i -> inner2.set(actX, actY + (float) actHeight * (i + 1) / hSegments),
                i -> outer1.set(ctrlLeft, ctrlTop + ctrlHeight * i / hSegments),
                i -> outer2.set(ctrlLeft, ctrlTop + ctrlHeight * (i + 1) / hSegments),
                true, ctrlCenter, time, inner1, inner2, outer1, outer2);

        // Right edge.
        renderSide(builder, hSegments,
                i -> inner1.set(actX + actWidth, actY + (float) actHeight * (i + 1) / hSegments),
                i -> inner2.set(actX + actWidth, actY + (float) actHeight * i / hSegments),
                i -> outer1.set(ctrlRight, ctrlTop + ctrlHeight * (i + 1) / hSegments),
                i -> outer2.set(ctrlRight, ctrlTop + ctrlHeight * i / hSegments),
                true, ctrlCenter, time, inner1, inner2, outer1, outer2);

        if (builder.isEmpty()) return;
        graphics.addGuiElement(builder.build(null));
    }

    private void renderSide(MeshRenderState.Builder builder, int segments,
                            IntConsumer inner1Setter, IntConsumer inner2Setter,
                            IntConsumer ctrl1Setter, IntConsumer ctrl2Setter,
                            boolean flip, Vector2f ctrlCenter, float time,
                            Vector2f inner1, Vector2f inner2,
                            Vector2f ctrl1, Vector2f ctrl2) {

        final var outer1 = new Vector2f();
        final var outer2 = new Vector2f();

        for (int i = 0; i < segments; i++) {

            inner1Setter.accept(i);
            inner2Setter.accept(i);
            ctrl1Setter.accept(i);
            ctrl2Setter.accept(i);

            final var a1 = ctrlCenter.angle(inner1);
            final var a2 = ctrlCenter.angle(inner2);

            final var t1 = 0.5f + 0.5f * (float) Math.cos(a1 * frequency + time * speed);
            final var t2 = 0.5f + 0.5f * (float) Math.cos(a2 * frequency + time * speed);

            outer1.set(inner1).lerp(ctrl1, 0.3f + 0.2f * t1);
            outer2.set(inner2).lerp(ctrl2, 0.3f + 0.2f * t2);

            final var c1 = innerColor.lerp(accentColor, t1);
            final var c2 = innerColor.lerp(accentColor, t2);

            if (flip) {
                builder.quad(
                        inner1.x, inner1.y, outer1.x, outer1.y,
                        c1, c1, outerColor, outerColor);
                builder.quad(
                        inner2.x, inner2.y, outer2.x, outer2.y,
                        c2, c2, outerColor, outerColor);
            } else {
                builder.quad(
                        inner2.x, inner2.y, outer2.x, outer2.y,
                        c2, c2, outerColor, outerColor);
                builder.quad(
                        inner1.x, inner1.y, outer1.x, outer1.y,
                        c1, c1, outerColor, outerColor);
            }
        }
    }

    static {
        TEXTURE = ObscureTooltips.key("textures/gui/effect/ray_glow.png");
        CODEC = RecordCodecBuilder.mapCodec(codec -> codec.group(
                Argb.CODEC.fieldOf("inner_color").forGetter(ShimmerEffect::innerColor),
                Argb.CODEC.fieldOf("accent_color").forGetter(ShimmerEffect::accentColor),
                Argb.CODEC.fieldOf("outer_color").forGetter(ShimmerEffect::outerColor),
                Codec.FLOAT.fieldOf("frequency").forGetter(ShimmerEffect::frequency),
                Codec.FLOAT.fieldOf("speed").forGetter(ShimmerEffect::speed)
        ).apply(codec, ShimmerEffect::new));
    }
}
