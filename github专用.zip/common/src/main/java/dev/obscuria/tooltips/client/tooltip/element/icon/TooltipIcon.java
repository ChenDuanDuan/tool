package dev.obscuria.tooltips.client.tooltip.element.icon;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import dev.obscuria.tooltips.client.TooltipState;
import dev.obscuria.tooltips.client.tooltip.element.Transform;
import dev.obscuria.tooltips.client.registry.TooltipRegistries;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import java.util.Map;

public interface TooltipIcon {

    Map<String, MapCodec<? extends TooltipIcon>> TYPES = new java.util.LinkedHashMap<>();

    Codec<TooltipIcon> DIRECT_CODEC = TooltipRegistries.tooltipIconCodec();
    Codec<TooltipIcon> CODEC = TooltipRegistries.Resource.TOOLTIP_ICON.byNameCodec();

    MapCodec<? extends TooltipIcon> codec();

    void render(TooltipState state, GuiGraphicsExtractor graphics, int x, int y);

    default void pushTransform(TooltipState state, Transform transform, GuiGraphicsExtractor graphics, int x, int y) {
        final var pose = graphics.pose();
        pose.pushMatrix();
        pose.translate((float) x, (float) y);
        pose.translate(transform.offset().x, transform.offset().y);
        pose.scale(transform.scale(), transform.scale());
        pose.rotate((float) Math.toRadians(transform.rotation()));
        applyScale(state, graphics, x, y);
        applyRotation(state, graphics, x, y);

        pose.pushMatrix();
        pose.translate(-8f, -8f);
    }

    default void popTransform(GuiGraphicsExtractor graphics) {
        graphics.pose().popMatrix();
        graphics.pose().popMatrix();
    }

    default void applyScale(TooltipState state, GuiGraphicsExtractor graphics, int x, int y) {}

    default void applyRotation(TooltipState state, GuiGraphicsExtractor graphics, int x, int y) {}

    static void bootstrapTypes() {
        TYPES.put("static", StaticIcon.CODEC);
        TYPES.put("accent", AccentIcon.CODEC);
        TYPES.put("accent_spin", AccentSpinIcon.CODEC);
        TYPES.put("accent_burst", AccentBurstIcon.CODEC);
    }

    static {
        bootstrapTypes();
    }
}
