package dev.obscuria.tooltips.client.tooltip.element;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.phys.Vec3;

public record Transform(
        Vec3 offset,
        float scale,
        float rotation) {

    public static final Transform DEFAULT = new Transform(Vec3.ZERO, 1f, 0f);
    public static final Codec<Transform> CODEC;

    /**
     * 26.3 keeps a 2D {@code Matrix3x2fStack}, so the z component of the offset and
     * the explicit pose multiplication are dropped; rotation becomes radians.
     */
    public void apply(GuiGraphicsExtractor graphics) {
        final var pose = graphics.pose();
        pose.translate((float) -offset.x, (float) -offset.y);
        pose.scale(scale, scale);
        pose.rotate((float) Math.toRadians(rotation));
    }

    static {
        CODEC = RecordCodecBuilder.create(codec -> codec.group(
                Vec3.CODEC.optionalFieldOf("offset", Vec3.ZERO).forGetter(Transform::offset),
                Codec.FLOAT.optionalFieldOf("scale", 1f).forGetter(Transform::scale),
                Codec.FLOAT.optionalFieldOf("rotation", 0f).forGetter(Transform::rotation)
        ).apply(codec, Transform::new));
    }
}
