package dev.obscuria.tooltips.client.tooltip.element.icon;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.obscuria.tooltips.client.math.Easing;
import dev.obscuria.tooltips.client.TooltipState;
import dev.obscuria.tooltips.client.tooltip.element.Transform;
import net.minecraft.client.gui.GuiGraphicsExtractor;

public record AccentIcon(Transform transform) implements TooltipIcon {

    public static final MapCodec<AccentIcon> CODEC;

    @Override
    public MapCodec<AccentIcon> codec() {
        return CODEC;
    }

    @Override
    public void render(TooltipState state, GuiGraphicsExtractor graphics, int x, int y) {
        pushTransform(state, transform, graphics, x, y);
        // TODO 26.3: item rendering inside a tooltip needs the GuiItemRenderState path.
        popTransform(graphics);
    }

    @Override
    public void applyScale(TooltipState state, GuiGraphicsExtractor graphics, int x, int y) {
        final var time = state.timeInSeconds();
        final var scale = (time < 0.25f)
                ? Easing.EASE_OUT_CUBIC.compute(time / 0.25f) * 1.25f
                : (time < 0.5f)
                ? 1.25f - 0.25f * Easing.EASE_OUT_CUBIC.compute((time - 0.25f) / 0.25f)
                : 1f;
        graphics.pose().scale(scale, scale);
    }

    static {
        CODEC = RecordCodecBuilder.mapCodec(codec -> codec.group(
                Transform.CODEC.fieldOf("transform").forGetter(AccentIcon::transform)
        ).apply(codec, AccentIcon::new));
    }
}
