package dev.obscuria.tooltips.client.color;

import com.mojang.serialization.Codec;
import net.minecraft.util.Mth;

/**
 * Local replacement for Fragmentum's Argb class so the port does not depend on
 * a specific Fragmentum release. Stored as a plain packed Argb int.
 */
public record Argb(int value) {

    public static final Argb WHITE = new Argb(0xFFFFFFFF);
    public static final Argb TRANSPARENT = new Argb(0x00000000);

    public static final Codec<Argb> CODEC = Codec.INT.xmap(Argb::new, Argb::value);

    public static Argb of(int red, int green, int blue, int alpha) {
        return new Argb((Mth.clamp(alpha, 0, 255) << 24)
                | (Mth.clamp(red, 0, 255) << 16)
                | (Mth.clamp(green, 0, 255) << 8)
                | Mth.clamp(blue, 0, 255));
    }

    public static Argb of(float red, float green, float blue, float alpha) {
        return of((int) (red * 255f), (int) (green * 255f), (int) (blue * 255f), (int) (alpha * 255f));
    }

    public static Argb rgb(int rgb) {
        return new Argb(0xFF000000 | (rgb & 0x00FFFFFF));
    }

    public int alpha() {
        return (value >>> 24) & 0xFF;
    }

    public int red() {
        return (value >>> 16) & 0xFF;
    }

    public int green() {
        return (value >>> 8) & 0xFF;
    }

    public int blue() {
        return value & 0xFF;
    }

    public float redFloat() {
        return red() / 255f;
    }

    public float greenFloat() {
        return green() / 255f;
    }

    public float blueFloat() {
        return blue() / 255f;
    }

    public float alphaFloat() {
        return alpha() / 255f;
    }

    public Argb withAlpha(int alpha) {
        return of(red(), green(), blue(), alpha);
    }

    public Argb lerp(Argb other, float delta) {
        final var t = Mth.clamp(delta, 0f, 1f);
        return of(
                (int) (red() + (other.red() - red()) * t),
                (int) (green() + (other.green() - green()) * t),
                (int) (blue() + (other.blue() - blue()) * t),
                (int) (alpha() + (other.alpha() - alpha()) * t));
    }

    public Argb multiplyAlpha(float factor) {
        return withAlpha((int) (alpha() * factor));
    }
}
