package dev.obscuria.tooltips.client.render;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.renderpearl.api.pipeline.RenderPipeline;
import dev.obscuria.tooltips.client.color.Argb;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.client.gui.render.TextureSetup;
import net.minecraft.client.renderer.state.gui.GuiElementRenderState;
import org.joml.Matrix3x2f;
import org.joml.Matrix3x2fc;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

/**
 * Arbitrary coloured triangle fan / quad list submitted as one GUI render state.
 * <p>
 * The tooltip effects build their geometry procedurally (shimmer rings, rim
 * light strips, particle lines). In 26.3 vertices are no longer written straight
 * into a {@code VertexConsumer}; a render state is queued and the vertices are
 * produced later in {@link #buildVertices}, so the points are captured here.
 */
public record MeshRenderState(
        RenderPipeline pipeline,
        TextureSetup textureSetup,
        Matrix3x2fc pose,
        List<Triangle> triangles,
        @Nullable ScreenRectangle scissorArea,
        @Nullable ScreenRectangle bounds
) implements GuiElementRenderState {

    public record Triangle(
            float x0, float y0, Argb c0,
            float x1, float y1, Argb c1,
            float x2, float y2, Argb c2
    ) {}

    public static Builder builder(RenderPipeline pipeline, Matrix3x2f pose) {
        return new Builder(pipeline, pose);
    }

    @Override
    public void buildVertices(VertexConsumer consumer) {
        for (var triangle : triangles) {
            vertex(consumer, triangle.x0(), triangle.y0(), triangle.c0());
            vertex(consumer, triangle.x1(), triangle.y1(), triangle.c1());
            vertex(consumer, triangle.x2(), triangle.y2(), triangle.c2());
        }
    }

    private void vertex(VertexConsumer consumer, float x, float y, Argb color) {
        consumer.addVertexWith2DPose(pose, x, y).setColor(color.value());
    }

    public static final class Builder {

        private final RenderPipeline pipeline;
        private final Matrix3x2f pose;
        private final List<Triangle> triangles = new ArrayList<>();

        private Builder(RenderPipeline pipeline, Matrix3x2f pose) {
            this.pipeline = pipeline;
            this.pose = pose;
        }

        /** Appends a quad as two triangles, keeping the four supplied corner colours. */
        public Builder quad(float x0, float y0, float x1, float y1,
                            Argb topLeft, Argb topRight, Argb bottomLeft, Argb bottomRight) {
            triangles.add(new Triangle(
                    x0, y0, topLeft,
                    x0, y1, bottomLeft,
                    x1, y1, bottomRight));
            triangles.add(new Triangle(
                    x0, y0, topLeft,
                    x1, y1, bottomRight,
                    x1, y0, topRight));
            return this;
        }

        /** Appends a single triangle. */
        public Builder triangle(float x0, float y0, Argb c0,
                                float x1, float y1, Argb c1,
                                float x2, float y2, Argb c2) {
            triangles.add(new Triangle(x0, y0, c0, x1, y1, c1, x2, y2, c2));
            return this;
        }

        public boolean isEmpty() {
            return triangles.isEmpty();
        }

        public MeshRenderState build(@Nullable ScreenRectangle scissorArea) {
            var minX = Float.MAX_VALUE;
            var minY = Float.MAX_VALUE;
            var maxX = -Float.MAX_VALUE;
            var maxY = -Float.MAX_VALUE;
            for (var triangle : triangles) {
                minX = Math.min(minX, Math.min(triangle.x0(), Math.min(triangle.x1(), triangle.x2())));
                maxX = Math.max(maxX, Math.max(triangle.x0(), Math.max(triangle.x1(), triangle.x2())));
                minY = Math.min(minY, Math.min(triangle.y0(), Math.min(triangle.y1(), triangle.y2())));
                maxY = Math.max(maxY, Math.max(triangle.y0(), Math.max(triangle.y1(), triangle.y2())));
            }
            final var local = new ScreenRectangle((int) minX, (int) minY,
                    (int) (maxX - minX), (int) (maxY - minY));
            final var transformed = local.transformMaxBounds(pose);
            final var bounds = scissorArea == null ? transformed : transformed.intersection(scissorArea);
            return new MeshRenderState(pipeline, TextureSetup.noTexture(), new Matrix3x2f(pose),
                    List.copyOf(triangles), scissorArea, bounds);
        }
    }
}
