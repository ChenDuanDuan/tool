package dev.obscuria.tooltips.client.render;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.renderpearl.api.pipeline.RenderPipeline;
import dev.obscuria.tooltips.client.color.Argb;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.client.gui.render.TextureSetup;
import net.minecraft.client.renderer.state.gui.GuiElementRenderState;
import org.joml.Matrix3x2f;
import org.joml.Matrix3x2fc;
import org.jetbrains.annotations.Nullable;

/**
 * A single quad with four independent corner colours.
 * <p>
 * Vanilla's {@code ColoredRectangleRenderState} only supports two colours (top /
 * bottom), which is not enough for Obscure Tooltips' {@code QuadPalette}
 * gradients, so this render state builds the vertices itself.
 */
public record QuadRenderState(
        RenderPipeline pipeline,
        TextureSetup textureSetup,
        Matrix3x2fc pose,
        float x0,
        float y0,
        float x1,
        float y1,
        Argb topLeft,
        Argb topRight,
        Argb bottomLeft,
        Argb bottomRight,
        @Nullable ScreenRectangle scissorArea,
        @Nullable ScreenRectangle bounds
) implements GuiElementRenderState {

    public static QuadRenderState of(
            RenderPipeline pipeline,
            Matrix3x2f pose,
            float x,
            float y,
            float width,
            float height,
            Argb topLeft,
            Argb topRight,
            Argb bottomLeft,
            Argb bottomRight,
            @Nullable ScreenRectangle scissorArea) {

        final var local = new ScreenRectangle((int) x, (int) y, (int) width, (int) height);
        final var bounds = scissorArea == null
                ? local.transformMaxBounds(pose)
                : local.transformMaxBounds(pose).intersection(scissorArea);
        return new QuadRenderState(pipeline, TextureSetup.noTexture(), new Matrix3x2f(pose),
                x, y, x + width, y + height,
                topLeft, topRight, bottomLeft, bottomRight,
                scissorArea, bounds);
    }

    @Override
    public void buildVertices(VertexConsumer consumer) {
        vertex(consumer, x0, y0, topLeft);
        vertex(consumer, x0, y1, bottomLeft);
        vertex(consumer, x1, y1, bottomRight);
        vertex(consumer, x1, y0, topRight);
    }

    private void vertex(VertexConsumer consumer, float x, float y, Argb color) {
        consumer.addVertexWith2DPose(pose, x, y).setColor(color.value());
    }
}
