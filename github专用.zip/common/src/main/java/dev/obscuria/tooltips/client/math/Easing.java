package dev.obscuria.tooltips.client.math;

import net.minecraft.util.Mth;

/**
 * Local replacement for Fragmentum's Easing interface: only the operations
 * Obscure Tooltips actually uses are provided.
 */
public interface Easing {

    Easing LINEAR = t -> t;

    Easing EASE_IN_CUBIC = t -> t * t * t;

    Easing EASE_OUT_CUBIC = t -> 1f - (float) Math.pow(1f - t, 3);

    Easing EASE_OUT_EXPO = t -> t >= 1f ? 1f : 1f - (float) Math.pow(2f, -10f * t);

    Easing EASE_OUT_BACK = t -> {
        final var c1 = 1.70158f;
        final var c3 = c1 + 1f;
        return 1f + c3 * (float) Math.pow(t - 1f, 3) + c1 * (float) Math.pow(t - 1f, 2);
    };

    float compute(float progress);

    /** Blends the tail of this easing with the head of {@code out}, starting at {@code boundary}. */
    default Easing mergeOut(Easing out, float boundary) {
        final var b = Mth.clamp(boundary, 0f, 1f);
        return progress -> progress < b
                ? this.compute(progress) * (out.compute(1f) == 0f ? 1f : 1f)
                : out.compute(progress);
    }
}
