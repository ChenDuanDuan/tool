package dev.obscuria.tooltips.client.tooltip.element.slot;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.obscuria.tooltips.client.color.Argb;
import dev.obscuria.tooltips.client.tooltip.element.QuadPalette;
import dev.obscuria.tooltips.client.tooltip.particle.GraphicUtils;
import net.minecraft.client.gui.GuiGraphicsExtractor;

public record ColorRectSlot(
        QuadPalette palette,
        Argb borders
) implements TooltipSlot {

    public static final MapCodec<ColorRectSlot> CODEC;

    @Override
    public MapCodec<ColorRectSlot> codec() {
        return CODEC;
    }

    @Override
    public void render(GuiGraphicsExtractor graphics, int x, int y, int width, int height) {
        GraphicUtils.drawRect(graphics, x + 1, y + 1, width - 2, height - 2, palette);
        GraphicUtils.drawHLine(graphics, x + 1, y, width - 2, borders, borders);
        GraphicUtils.drawHLine(graphics, x + 1, y + height - 1, width - 2, borders, borders);
        GraphicUtils.drawVLine(graphics, x, y + 1, height - 2, borders, borders);
        GraphicUtils.drawVLine(graphics, x + width - 1, y + 1, height - 2, borders, borders);
    }

    static {
        CODEC = RecordCodecBuilder.mapCodec(codec -> codec.group(
                QuadPalette.CODEC.fieldOf("palette").forGetter(ColorRectSlot::palette),
                Argb.CODEC.fieldOf("borders").forGetter(ColorRectSlot::borders)
        ).apply(codec, ColorRectSlot::new));
    }
}
