package dev.obscuria.tooltips.client.tooltip.filter;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import dev.obscuria.tooltips.client.registry.TooltipRegistries;
import net.minecraft.world.item.ItemStack;

import java.util.Map;

public interface ItemFilter {

    Map<String, MapCodec<? extends ItemFilter>> TYPES = new java.util.LinkedHashMap<>();

    Codec<ItemFilter> CODEC = TooltipRegistries.itemFilterCodec();

    MapCodec<? extends ItemFilter> codec();

    boolean test(ItemStack stack);

    static void bootstrapTypes() {
        TYPES.put("always", AlwaysFilter.CODEC);
        TYPES.put("never", NeverFilter.CODEC);
        TYPES.put("all_of", AllOfFilter.CODEC);
        TYPES.put("any_of", AnyOfFilter.CODEC);
        TYPES.put("none_of", NoneOfFilter.CODEC);
        TYPES.put("item", ItemOrTagFilter.CODEC);
        TYPES.put("mod", ModFilter.CODEC);
        TYPES.put("enchantment", EnchantmentFilter.CODEC);
        TYPES.put("rarity", RarityFilter.CODEC);
        TYPES.put("nbt", NbtFilter.CODEC);
        TYPES.put("property", PropertyFilter.CODEC);
    }

    static {
        bootstrapTypes();
    }
}
