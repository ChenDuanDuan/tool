package dev.obscuria.tooltips.client.tooltip.element.effect;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.obscuria.tooltips.client.TooltipState;
import dev.obscuria.tooltips.client.render.MeshRenderState;
import dev.obscuria.tooltips.client.tooltip.element.QuadPalette;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;

import java.util.List;

public record RimLightEffect(
        QuadPalette outerPalette,
        QuadPalette innerPalette
) implements TooltipEffect {

    public static final MapCodec<RimLightEffect> CODEC;

    @Override
    public MapCodec<RimLightEffect> codec() {
        return CODEC;
    }

    @Override
    public boolean canApply(List<TooltipEffect> effects) {
        return effects.stream().noneMatch(it -> it instanceof RimLightEffect);
    }

    /**
     * Ported from immediate-mode vertex writes to a single {@link MeshRenderState}.
     * The old code emitted four outer edges plus two inner triangles; both are kept
     * as quads so the gradient corners survive.
     */
    @Override
    public void renderBack(TooltipState state, GuiGraphicsExtractor graphics, int x, int y, int width, int height) {

        final var pX = x - 3f;
        final var pY = y - 3f;
        final var pWidth = width + 6f;
        final var pHeight = height + 6f;

        final var scale = 0.8f + 0.4f * (float) Math.cos(state.timeInSeconds());
        final var offset = Math.min(pWidth, pHeight) * 0.25f * scale;

        final var builder = MeshRenderState.builder(RenderPipelines.GUI_TEXTURED_PREMULTIPLIED_ALPHA,
                graphics.pose());

        // Top edge: outer -> inner on both sides.
        builder.quad(pX, pY, pX + offset, pY + offset,
                outerPalette.topLeft(), outerPalette.topLeft(),
                innerPalette.topLeft(), innerPalette.topLeft());
        builder.quad(pX + pWidth - offset, pY + offset, pX + pWidth, pY,
                innerPalette.topRight(), innerPalette.topRight(),
                outerPalette.topRight(), outerPalette.topRight());

        // Bottom edge.
        builder.quad(pX, pY + pHeight, pX + offset, pY + pHeight - offset,
                outerPalette.bottomLeft(), innerPalette.bottomLeft(),
                outerPalette.bottomLeft(), innerPalette.bottomLeft());
        builder.quad(pX + pWidth - offset, pY + pHeight - offset, pX + pWidth, pY + pHeight,
                innerPalette.bottomRight(), outerPalette.bottomRight(),
                innerPalette.bottomRight(), outerPalette.bottomRight());

        // Left edge.
        builder.quad(pX, pY, pX + offset, pY,
                outerPalette.topLeft(), outerPalette.topLeft(),
                innerPalette.topLeft(), innerPalette.topLeft());
        builder.quad(pX, pY + pHeight, pX + offset, pY + pHeight,
                outerPalette.bottomLeft(), innerPalette.bottomLeft(),
                outerPalette.bottomLeft(), innerPalette.bottomLeft());

        // Right edge.
        builder.quad(pX + pWidth - offset, pY, pX + pWidth, pY,
                innerPalette.topRight(), outerPalette.topRight(),
                innerPalette.topRight(), outerPalette.topRight());
        builder.quad(pX + pWidth - offset, pY + pHeight, pX + pWidth, pY + pHeight,
                innerPalette.bottomRight(), outerPalette.bottomRight(),
                innerPalette.bottomRight(), outerPalette.bottomRight());

        if (builder.isEmpty()) return;
        graphics.addGuiElement(builder.build(null));
    }

    static {
        CODEC = RecordCodecBuilder.mapCodec(codec -> codec.group(
                QuadPalette.CODEC.fieldOf("outer_palette").forGetter(RimLightEffect::outerPalette),
                QuadPalette.CODEC.fieldOf("inner_palette").forGetter(RimLightEffect::innerPalette)
        ).apply(codec, RimLightEffect::new));
    }
}
