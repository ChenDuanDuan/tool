package dev.obscuria.tooltips.client.tooltip.label;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import dev.obscuria.tooltips.client.registry.TooltipRegistries;
import net.minecraft.client.gui.screens.inventory.tooltip.ClientTooltipComponent;
import net.minecraft.world.item.ItemStack;

import java.util.Map;

public interface LabelProvider {

    Map<String, MapCodec<? extends LabelProvider>> TYPES = new java.util.LinkedHashMap<>();

    Codec<LabelProvider> CODEC = TooltipRegistries.labelProviderCodec();

    MapCodec<? extends LabelProvider> codec();

    ClientTooltipComponent create(ItemStack stack);

    static void bootstrapTypes() {
        TYPES.put("blank", BlankLabelProvider.CODEC);
        TYPES.put("literal", LiteralLabelProvider.CODEC);
        TYPES.put("translatable", TranslatableLabelProvider.CODEC);
        TYPES.put("rarity", RarityLabelProvider.CODEC);
    }

    static {
        bootstrapTypes();
    }
}
