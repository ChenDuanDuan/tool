package dev.obscuria.tooltips;

import dev.obscuria.tooltips.client.component.StackBuffer;
import dev.obscuria.tooltips.client.registry.TooltipRegistries;
import dev.obscuria.tooltips.config.ClientConfig;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public interface ObscureTooltips {

    String MODID = "obscure_tooltips";
    String DISPLAY_NAME = "Obscure Tooltips";
    Logger LOGGER = LoggerFactory.getLogger(DISPLAY_NAME);

    static Identifier key(String name) {
        return Identifier.fromNamespaceAndPath(MODID, name);
    }

    /**
     * Fragmentum hooks removed for the 26.3 port: the tooltip component registry
     * entry and the built-in "Vibrant Tooltips" pack. Core tooltips only need the
     * config + registries to be up, and StackBuffer is discovered directly by
     * {@code TooltipRenderer}.
     */
    static void init() {
        ClientConfig.init();
        TooltipRegistries.init();
        LOGGER.info("Obscure Tooltips initialised ({} stacks buffered)", StackBuffer.class.getSimpleName());
    }
}
