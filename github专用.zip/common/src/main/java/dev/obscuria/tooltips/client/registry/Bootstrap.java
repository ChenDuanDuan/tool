package dev.obscuria.tooltips.client.registry;

import com.mojang.serialization.MapCodec;

import java.util.Map;

/**
 * Minimal stand-in for Fragmentum's BootstrapContext: collects entries into a
 * plain map keyed by name instead of a game registry.
 */
public final class Bootstrap<T> {

    private final Map<String, T> entries = new java.util.LinkedHashMap<>();

    public static <T> Bootstrap<T> create() {
        return new Bootstrap<>();
    }

    public void register(String name, java.util.function.Supplier<T> supplier) {
        entries.put(name, supplier.get());
    }

    public Map<String, T> entries() {
        return entries;
    }
}
