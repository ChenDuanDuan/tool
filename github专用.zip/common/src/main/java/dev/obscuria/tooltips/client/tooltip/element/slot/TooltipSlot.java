package dev.obscuria.tooltips.client.tooltip.element.slot;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import dev.obscuria.tooltips.client.registry.TooltipRegistries;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import java.util.Map;

public interface TooltipSlot {

    Map<String, MapCodec<? extends TooltipSlot>> TYPES = new java.util.LinkedHashMap<>();

    Codec<TooltipSlot> DIRECT_CODEC = TooltipRegistries.tooltipSlotCodec();
    Codec<TooltipSlot> CODEC = TooltipRegistries.Resource.TOOLTIP_SLOT.byNameCodec();

    MapCodec<? extends TooltipSlot> codec();

    void render(GuiGraphicsExtractor graphics, int x, int y, int width, int height);

    static void bootstrapTypes() {
        TYPES.put("blank", BlankSlot.CODEC);
        TYPES.put("color_rect", ColorRectSlot.CODEC);
    }

    static {
        bootstrapTypes();
    }
}
