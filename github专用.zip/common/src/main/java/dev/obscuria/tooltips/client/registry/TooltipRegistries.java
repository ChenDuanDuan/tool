package dev.obscuria.tooltips.client.registry;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import dev.obscuria.tooltips.client.tooltip.TooltipDefinition;
import dev.obscuria.tooltips.client.tooltip.TooltipLabel;
import dev.obscuria.tooltips.client.tooltip.TooltipStyle;
import dev.obscuria.tooltips.client.tooltip.element.effect.TooltipEffect;
import dev.obscuria.tooltips.client.tooltip.element.frame.TooltipFrame;
import dev.obscuria.tooltips.client.tooltip.element.icon.TooltipIcon;
import dev.obscuria.tooltips.client.tooltip.element.panel.TooltipPanel;
import dev.obscuria.tooltips.client.tooltip.element.slot.TooltipSlot;
import dev.obscuria.tooltips.client.tooltip.filter.ItemFilter;
import dev.obscuria.tooltips.client.tooltip.label.LabelProvider;
import dev.obscuria.tooltips.client.tooltip.layout.TooltipLayout;
import dev.obscuria.tooltips.client.tooltip.particle.TooltipParticle;

import java.util.Map;

/**
 * Registry layer rebuilt on plain maps instead of Fragmentum's game registries.
 * <p>
 * Each element interface fills a {@code Map<String, MapCodec<? extends T>>} during
 * its own static initialisation; the tables are exposed here so the shared
 * dispatch codec in {@link TypeDispatch} can resolve the inline "type" field.
 */
public interface TooltipRegistries {

    interface Types {

        Map<String, MapCodec<? extends ItemFilter>> ITEM_FILTER = ItemFilter.TYPES;
        Map<String, MapCodec<? extends LabelProvider>> LABEL_PROVIDER = LabelProvider.TYPES;
        Map<String, MapCodec<? extends TooltipParticle>> TOOLTIP_PARTICLE = TooltipParticle.TYPES;
        Map<String, MapCodec<? extends TooltipPanel>> TOOLTIP_PANEL = TooltipPanel.TYPES;
        Map<String, MapCodec<? extends TooltipFrame>> TOOLTIP_FRAME = TooltipFrame.TYPES;
        Map<String, MapCodec<? extends TooltipSlot>> TOOLTIP_SLOT = TooltipSlot.TYPES;
        Map<String, MapCodec<? extends TooltipIcon>> TOOLTIP_ICON = TooltipIcon.TYPES;
        Map<String, MapCodec<? extends TooltipEffect>> TOOLTIP_EFFECT = TooltipEffect.TYPES;
        Map<String, MapCodec<? extends TooltipLayout<?>>> TOOLTIP_LAYOUT = TooltipLayout.TYPES;
    }

    interface Resource {

        ResourceRegistry<TooltipPanel> TOOLTIP_PANEL = new ResourceRegistry<>("panel");
        ResourceRegistry<TooltipFrame> TOOLTIP_FRAME = new ResourceRegistry<>("frame");
        ResourceRegistry<TooltipSlot> TOOLTIP_SLOT = new ResourceRegistry<>("slot");
        ResourceRegistry<TooltipIcon> TOOLTIP_ICON = new ResourceRegistry<>("icon");
        ResourceRegistry<TooltipEffect> TOOLTIP_EFFECT = new ResourceRegistry<>("effect");
        ResourceRegistry<TooltipStyle> TOOLTIP_STYLE = new ResourceRegistry<>("style");
        ResourceRegistry<TooltipDefinition> TOOLTIP_DEFINITION = new ResourceRegistry.Ordered<>("definition");
        ResourceRegistry<TooltipLabel> TOOLTIP_LABEL = new ResourceRegistry.Ordered<>("label");
    }

    static Codec<ItemFilter> itemFilterCodec() {
        return TypeDispatch.of(Types.ITEM_FILTER);
    }

    static Codec<LabelProvider> labelProviderCodec() {
        return TypeDispatch.of(Types.LABEL_PROVIDER);
    }

    static Codec<TooltipParticle> tooltipParticleCodec() {
        return TypeDispatch.of(Types.TOOLTIP_PARTICLE);
    }

    static Codec<TooltipPanel> tooltipPanelCodec() {
        return TypeDispatch.of(Types.TOOLTIP_PANEL);
    }

    static Codec<TooltipFrame> tooltipFrameCodec() {
        return TypeDispatch.of(Types.TOOLTIP_FRAME);
    }

    static Codec<TooltipSlot> tooltipSlotCodec() {
        return TypeDispatch.of(Types.TOOLTIP_SLOT);
    }

    static Codec<TooltipIcon> tooltipIconCodec() {
        return TypeDispatch.of(Types.TOOLTIP_ICON);
    }

    static Codec<TooltipEffect> tooltipEffectCodec() {
        return TypeDispatch.of(Types.TOOLTIP_EFFECT);
    }

    static void init() {
        // Touching the interface tables forces every element type list to load.
        Types.ITEM_FILTER.size();
        Types.LABEL_PROVIDER.size();
        Types.TOOLTIP_PARTICLE.size();
        Types.TOOLTIP_PANEL.size();
        Types.TOOLTIP_FRAME.size();
        Types.TOOLTIP_SLOT.size();
        Types.TOOLTIP_ICON.size();
        Types.TOOLTIP_EFFECT.size();
        Types.TOOLTIP_LAYOUT.size();
    }
}
