package dev.obscuria.tooltips.client.registry;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import net.minecraft.util.ExtraCodecs;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Builds the "type" dispatching codec shared by every polymorphic tooltip element.
 * <p>
 * Each {@code *Type} interface exposes {@link #newMap()} and fills it in a
 * {@code bootstrapTypes()} method; call {@link #of} after bootstrapping.
 */
public final class TypeDispatch {

    private TypeDispatch() {}

    public static <T> Map<String, MapCodec<? extends T>> newMap() {
        return new LinkedHashMap<>();
    }

    /**
     * Vanilla pattern: an inline "type" string resolves to {@code IdMapper} entry,
     * whose codec then decodes the rest of the object.
     */
    public static <T> Codec<T> of(Map<String, MapCodec<? extends T>> types) {
        final var mapper = ExtraCodecs.lateBoundIdMapper();
        types.forEach(mapper::put);
        return mapper.codec(MapCodec::codec)
                .dispatch(value -> value.codec(), MapCodec::codec);
    }
}
