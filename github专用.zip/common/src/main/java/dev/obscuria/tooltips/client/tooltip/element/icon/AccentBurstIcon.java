package dev.obscuria.tooltips.client.tooltip.element.icon;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.obscuria.tooltips.client.math.Easing;
import dev.obscuria.tooltips.client.TooltipState;
import dev.obscuria.tooltips.client.tooltip.element.Transform;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.util.Mth;

public record AccentBurstIcon(Transform transform) implements TooltipIcon {

    public static final MapCodec<AccentBurstIcon> CODEC;

    @Override
    public MapCodec<AccentBurstIcon> codec() {
        return CODEC;
    }

    @Override
    public void render(TooltipState state, GuiGraphicsExtractor graphics, int x, int y) {
        pushTransform(state, transform, graphics, x, y);
        // TODO 26.3: item rendering inside a tooltip needs the GuiItemRenderState path.
        popTransform(graphics);
    }

    @Override
    public void applyScale(TooltipState state, GuiGraphicsExtractor graphics, int x, int y) {
        final var time = state.timeInSeconds();
        final var scale = (time < 0.25f)
                ? Easing.EASE_OUT_CUBIC.compute(time / 0.25f) * 1.75f
                : (time < 0.5f)
                ? 1.75f - 0.75f * Easing.EASE_OUT_BACK.compute((time - 0.25f) / 0.25f)
                : 1f;
        graphics.pose().scale(scale, scale);
    }

    @Override
    public void applyRotation(TooltipState state, GuiGraphicsExtractor graphics, int x, int y) {
        final var rotation = 360f * Mth.clamp(Easing.EASE_OUT_EXPO.compute(state.timeInSeconds()), 0f, 1f);
        graphics.pose().rotate((float) Math.toRadians(rotation));
    }

    static {
        CODEC = RecordCodecBuilder.mapCodec(codec -> codec.group(
                Transform.CODEC.fieldOf("transform").forGetter(AccentBurstIcon::transform)
        ).apply(codec, AccentBurstIcon::new));
    }
}
