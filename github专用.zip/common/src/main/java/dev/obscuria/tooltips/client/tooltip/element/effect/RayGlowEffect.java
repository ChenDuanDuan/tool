package dev.obscuria.tooltips.client.tooltip.element.effect;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.obscuria.tooltips.client.TooltipState;
import dev.obscuria.tooltips.client.color.Argb;
import dev.obscuria.tooltips.client.math.Easing;
import dev.obscuria.tooltips.client.tooltip.particle.GraphicUtils;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

import java.util.List;

/**
 * Glow ray behind the item icon, drawn as three rotated blits.
 * <p>
 * The 1.21.1 version relied on {@code RenderSystem} blend-mode switching plus a
 * global shader colour, neither of which applies to queued GUI render states.
 * The tint is baked into the blit colour instead, and additive blending is
 * dropped until it can be expressed via a dedicated pipeline.
 */
public record RayGlowEffect(Argb primaryColor, Argb secondaryColor) implements TooltipEffect {

    public static final Identifier TEXTURE;
    public static final MapCodec<RayGlowEffect> CODEC;

    @Override
    public MapCodec<RayGlowEffect> codec() {
        return CODEC;
    }

    @Override
    public boolean canApply(List<TooltipEffect> effects) {
        return effects.stream().noneMatch(it -> it instanceof RayGlowEffect);
    }

    @Override
    public void renderIcon(TooltipState state, GuiGraphicsExtractor graphics, int x, int y) {
        final var time = state.timeInSeconds();
        final var base = Mth.clamp(Easing.EASE_OUT_CUBIC.compute(time / 0.5f), 0f, 1f);
        final var scale = base + 0.75f * Math.max(0f,
                Easing.EASE_IN_CUBIC.mergeOut(Easing.EASE_OUT_CUBIC, 0.35f).compute(time));

        renderSegment(graphics, x, y, 1f * scale, 0.5f, time, primaryColor);
        renderSegment(graphics, x, y, 0.75f * scale, -0.33f, time,
                primaryColor.lerp(secondaryColor, 0.5f));
        renderSegment(graphics, x, y, 0.5f * scale, 0.25f, time, secondaryColor);
    }

    private void renderSegment(GuiGraphicsExtractor graphics, int x, int y,
                               float scale, float rotDelta, float timer, Argb color) {

        final var pose = graphics.pose();
        pose.pushMatrix();
        pose.translate((float) x, (float) y);
        pose.scale(scale, scale);
        pose.rotate(rotDelta * 3f + rotDelta * timer);
        graphics.blit(GraphicUtils.texturedPipeline(), TEXTURE, -32, -32, 0f, 0f, 64, 64, 64, 64);
        pose.popMatrix();
    }

    static {
        TEXTURE = dev.obscuria.tooltips.ObscureTooltips.key("textures/gui/effect/ray_glow.png");
        CODEC = RecordCodecBuilder.mapCodec(codec -> codec.group(
                Argb.CODEC.fieldOf("primary_color").forGetter(RayGlowEffect::primaryColor),
                Argb.CODEC.fieldOf("secondary_color").forGetter(RayGlowEffect::secondaryColor)
        ).apply(codec, RayGlowEffect::new));
    }
}
