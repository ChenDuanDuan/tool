package dev.obscuria.tooltips.client.tooltip.element.frame;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.obscuria.tooltips.client.render.QuadRenderState;
import dev.obscuria.tooltips.client.tooltip.particle.GraphicUtils;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;

/**
 * Nine-sliced decorative overlay.
 * <p>
 * The original blitted six 45x45 patches from a 140x140 sheet. Direct
 * {@code blit} calls are no longer immediate mode in 26.3, so the patches are
 * submitted as {@link QuadRenderState}s sharing one texture setup.
 */
public record NineSlicedFrame(Identifier textureSheet) implements TooltipFrame {

    public static final MapCodec<NineSlicedFrame> CODEC;

    @Override
    public MapCodec<NineSlicedFrame> codec() {
        return CODEC;
    }

    @Override
    public void render(GuiGraphicsExtractor graphics, int x, int y, int width, int height) {
        // Texture-space 140x140 sheet, 45x45 corners, 1px inset.
        patch(graphics, x - 31, y - 31, 1f, 1f);
        patch(graphics, x + width - 14, y - 31, 93f, 1f);
        patch(graphics, x - 31, y + height - 14, 1f, 93f);
        patch(graphics, x + width - 14, y + height - 14, 93f, 93f);
        patch(graphics, x + width / 2 - 23, y - 31, 47f, 1f);
        patch(graphics, x + width / 2 - 23, y + height - 14, 47f, 93f);
    }

    private void patch(GuiGraphicsExtractor graphics, int x, int y, float u, float v) {
        final var pose = graphics.pose();
        pose.pushMatrix();
        pose.translate(x, y);
        GraphicUtils.drawSprite(graphics, RenderPipelines.GUI_TEXTURED, textureSheet,
                u, v, 0, 0, 45, 45, 140f, 140f);
        pose.popMatrix();
    }

    static {
        CODEC = RecordCodecBuilder.mapCodec(codec -> codec.group(
                Identifier.CODEC.fieldOf("texture_sheet").forGetter(NineSlicedFrame::textureSheet)
        ).apply(codec, NineSlicedFrame::new));
    }
}
