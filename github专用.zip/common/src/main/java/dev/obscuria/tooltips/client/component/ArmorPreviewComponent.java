package dev.obscuria.tooltips.client.component;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.tooltip.ClientTooltipComponent;
import net.minecraft.world.entity.decoration.ArmorStand;

/**
 * 3D armor stand preview.
 * <p>
 * The 1.21.1 implementation used {@code drawManaged} with an immediate entity
 * render call taking a {@code PoseStack} and a {@code MultiBufferSource}. Neither
 * exists for GUI in 26.3 (geometry is queued as render states, and the GUI pose is
 * a {@code Matrix3x2fStack}), so the preview is disabled for now while keeping the
 * layout space it reserves.
 */
public record ArmorPreviewComponent(ArmorStand armorStand) implements ClientTooltipComponent {

    @Override
    public int getHeight() {
        return 64;
    }

    @Override
    public int getWidth(Font font) {
        return 40;
    }

    @Override
    public void extractImage(Font font, int x, int y, int width, int height, GuiGraphicsExtractor graphics) {
        // TODO 26.3: needs a picture-in-picture renderer (see GuiEntityRenderer) so the
        // armor stand model can be drawn into a texture and blitted back.
    }

    @Override
    public void extractText(GuiGraphicsExtractor graphics, Font font, int x, int y) {
        // No text.
    }
}
