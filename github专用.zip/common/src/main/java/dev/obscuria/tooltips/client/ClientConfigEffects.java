package dev.obscuria.tooltips.client;

/**
 * Feature switches for the first 26.3 build.
 * <p>
 * Effects and particles depend on the rewritten pose / vertex pipeline, so they
 * stay off until the basic panel + frame + text path is verified in game.
 * Flip {@link #ENABLED} back on once the styling layer is ported.
 */
public final class ClientConfigEffects {

    public static final boolean ENABLED = false;
    public static final boolean PARTICLES_ENABLED = false;

    private ClientConfigEffects() {}
}
