package dev.obscuria.tooltips.client.tooltip.particle;

import com.mojang.renderpearl.api.pipeline.RenderPipeline;
import dev.obscuria.tooltips.client.TooltipState;
import dev.obscuria.tooltips.client.color.Argb;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix3x2f;

/**
 * Small drawing helpers.
 * <p>
 * 26.3 queues GUI geometry instead of writing vertices immediately, so these
 * helpers all end in {@code addGuiElement} (or {@code blit}, which queues a
 * {@code BlitRenderState} internally).
 */
public interface GraphicUtils {

    Argb WHITE = Argb.WHITE;

    static RenderPipeline overlayPipeline() {
        return RenderPipelines.GUI_TEXTURED_PREMULTIPLIED_ALPHA;
    }

    static RenderPipeline pipeline() {
        return RenderPipelines.GUI;
    }

    static RenderPipeline texturedPipeline() {
        return RenderPipelines.GUI_TEXTURED;
    }

    static @Nullable ScreenRectangle scissor(GuiGraphicsExtractor graphics) {
        return null;
    }

    static void drawFrame(GuiGraphicsExtractor graphics, int x, int y, int width, int height, dev.obscuria.tooltips.client.tooltip.element.QuadPalette palette) {
        drawFrame(graphics, x, y, width, height,
                palette.topLeft(), palette.topRight(), palette.bottomLeft(), palette.bottomRight());
    }

    static void drawFrame(GuiGraphicsExtractor graphics, int x, int y, int width, int height,
                          Argb topLeft, Argb topRight, Argb bottomLeft, Argb bottomRight) {
        drawHLine(graphics, x, y, width, topLeft, topRight);
        drawHLine(graphics, x, y + height - 1, width, bottomLeft, bottomRight);
        drawVLine(graphics, x, y + 1, height - 2, topLeft, bottomLeft);
        drawVLine(graphics, x + width - 1, y + 1, height - 2, topRight, bottomRight);
    }

    static void drawHLine(GuiGraphicsExtractor graphics, int x, int y, int length, Argb start, Argb end) {
        drawRect(graphics, pipeline(), x, y, length, 1, start, end, start, end);
    }

    static void drawVLine(GuiGraphicsExtractor graphics, int x, int y, int length, Argb start, Argb end) {
        drawRect(graphics, pipeline(), x, y, 1, length, start, start, end, end);
    }

    static void drawHLineOverlay(GuiGraphicsExtractor graphics, int x, int y, int length, Argb start, Argb end) {
        drawRect(graphics, overlayPipeline(), x, y, length, 1, start, end, start, end);
    }

    static void drawVLineOverlay(GuiGraphicsExtractor graphics, int x, int y, int length, Argb start, Argb end) {
        drawRect(graphics, overlayPipeline(), x, y, 1, length, start, start, end, end);
    }

    static void drawRect(GuiGraphicsExtractor graphics, int x, int y, int width, int height,
                         dev.obscuria.tooltips.client.tooltip.element.QuadPalette palette) {
        drawRect(graphics, pipeline(), x, y, width, height,
                palette.topLeft(), palette.topRight(), palette.bottomLeft(), palette.bottomRight());
    }

    static void drawRect(GuiGraphicsExtractor graphics, RenderPipeline pipeline,
                         int x, int y, int width, int height,
                         Argb topLeft, Argb topRight, Argb bottomLeft, Argb bottomRight) {

        if (width <= 0 || height <= 0) return;
        graphics.addGuiElement(dev.obscuria.tooltips.client.render.QuadRenderState.of(
                pipeline, graphics.pose(),
                x, y, width, height, topLeft, topRight, bottomLeft, bottomRight, scissor(graphics)));
    }

    /** Queues a 1:1 sprite blit against the supplied pose. */
    static void drawSprite(GuiGraphicsExtractor graphics, RenderPipeline pipeline, Identifier texture,
                           float u, float v, int x, int y, int width, int height,
                           int textureWidth, int textureHeight) {
        graphics.blit(pipeline, texture, x, y, u, v, width, height, textureWidth, textureHeight);
    }

    /** Applies a 2D pose, runs {@code body}, then restores. */
    static void withPose(GuiGraphicsExtractor graphics, Matrix3x2f pose, Runnable body) {
        final var stack = graphics.pose();
        stack.pushMatrix();
        stack.mul(pose);
        body.run();
        stack.popMatrix();
    }

    static TooltipState stateOf(Object value) {
        return (TooltipState) value;
    }
}
