package dev.obscuria.tooltips.config;

import dev.obscuria.tooltips.client.color.Argb;

/**
 * Static, hard-coded settings for the first 26.3 build.
 * <p>
 * Fragmentum's {@code ConfigBuilder}/{@code ConfigValue} pair (backed by
 * forge-config-api-port) is not ported yet, so every value keeps the default the
 * 1.21.1 release shipped with. {@link #get()} is kept on the value holder so the
 * call sites did not need to change.
 */
public final class ClientConfig {

    public static final Held<Boolean> ENABLED = new Held<>(true);
    public static final Held<Boolean> LABELS_ENABLED = new Held<>(true);
    public static final Held<Boolean> SHADOWS_ENABLED = new Held<>(true);
    public static final Held<Double> SHADOW_OPACITY = new Held<>(0.3);

    public static final Held<Integer> CONTENT_MARGIN = new Held<>(3);
    public static final Held<java.util.List<? extends String>> IGNORED_ITEMS =
            new Held<>(java.util.List.of("quality_equipment:reforge_gui_button"));

    public static final Held<Boolean> AUTO_WRAPPING_ENABLED = new Held<>(true);

    public static final Held<Boolean> SCROLL_ENABLED = new Held<>(true);
    public static final Held<Integer> SCROLL_SPEED = new Held<>(5);
    public static final Held<Integer> SCROLL_MARGIN = new Held<>(10);

    public static final Held<Boolean> ARMOR_PREVIEW_ENABLED = new Held<>(true);
    public static final Held<java.util.List<? extends String>> ARMOR_PREVIEW_WHITELIST =
            new Held<>(java.util.List.of());
    public static final Held<java.util.List<? extends String>> ARMOR_PREVIEW_BLACKLIST =
            new Held<>(java.util.List.of());

    public static final Held<Boolean> TOOL_PREVIEW_ENABLED = new Held<>(false);
    public static final Held<java.util.List<? extends String>> TOOL_PREVIEW_WHITELIST =
            new Held<>(java.util.List.of("minecraft:trident", "minecraft:bow",
                    "minecraft:crossbow", "minecraft:mace"));
    public static final Held<java.util.List<? extends String>> TOOL_PREVIEW_BLACKLIST =
            new Held<>(java.util.List.of());

    private ClientConfig() {}

    public static final class Held<T> {

        private final T value;

        public Held(T value) {
            this.value = value;
        }

        public T get() {
            return value;
        }
    }

    public static boolean isIgnored(net.minecraft.world.item.Item item) {
        return IGNORED_ITEMS.get().contains(idOf(item));
    }

    public static boolean isInArmorPreviewWhitelist(net.minecraft.world.item.Item item) {
        return ARMOR_PREVIEW_WHITELIST.get().contains(idOf(item));
    }

    public static boolean isInArmorPreviewBlacklist(net.minecraft.world.item.Item item) {
        return ARMOR_PREVIEW_BLACKLIST.get().contains(idOf(item));
    }

    public static boolean isInToolPreviewWhitelist(net.minecraft.world.item.Item item) {
        return TOOL_PREVIEW_WHITELIST.get().contains(idOf(item));
    }

    public static boolean isInToolPreviewBlacklist(net.minecraft.world.item.Item item) {
        return TOOL_PREVIEW_BLACKLIST.get().contains(idOf(item));
    }

    private static String idOf(net.minecraft.world.item.Item item) {
        return item.builtInRegistryHolder().key().location().toString();
    }

    public static void init() {}
}
