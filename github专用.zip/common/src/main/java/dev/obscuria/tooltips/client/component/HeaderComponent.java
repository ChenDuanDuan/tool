package dev.obscuria.tooltips.client.component;

import dev.obscuria.tooltips.client.color.Argb;
import dev.obscuria.tooltips.client.color.Colors;
import dev.obscuria.tooltips.client.TooltipState;
import dev.obscuria.tooltips.client.tooltip.particle.GraphicUtils;
import dev.obscuria.tooltips.config.ClientConfig;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.tooltip.ClientTooltipComponent;

public record HeaderComponent(
        boolean drawDelimiter,
        TooltipState state,
        ClientTooltipComponent title,
        ClientTooltipComponent label
) implements ClientTooltipComponent {

    private static final Argb SEPARATOR_EDGE = Colors.argbOf(0x00ffffff);
    private static final Argb SEPARATOR_CENTER = Colors.argbOf(0x60ffffff);

    @Override
    public int getHeight() {
        return drawDelimiter ? 25 : 22;
    }

    @Override
    public int getWidth(Font font) {
        return 22 + Math.max(title.getWidth(font), label.getWidth(font));
    }

    /**
     * 26.3 replaced {@code renderText(font, x, y, Matrix4f, MultiBufferSource)} with
     * {@code extractText(graphics, font, x, y)}: text is queued as a
     * {@code GuiTextRenderState} against the current 2D pose.
     */
    @Override
    public void extractText(GuiGraphicsExtractor graphics, Font font, int x, int y) {
        if (!ClientConfig.LABELS_ENABLED.get() || label instanceof BlankComponent) {
            title.extractText(graphics, font, 22 + x, 1 + y + 5);
        } else {
            title.extractText(graphics, font, 22 + x, 1 + y);
            label.extractText(graphics, font, 22 + x, 1 + y + title.getHeight());
        }
    }

    @Override
    public void extractImage(Font font, int x, int y, int width, int height, GuiGraphicsExtractor graphics) {
        state.style.slot().ifPresent(it -> it.render(graphics, x, y, 20, 20));
        state.style.effects().forEach(it -> it.renderIcon(state, graphics, x + 10, y + 10));
        state.style.icon().ifPresent(it -> it.render(state, graphics, x + 10, y + 10));

        if (!drawDelimiter) return;
        final var length = getWidth(font) / 2;
        GraphicUtils.drawHLine(graphics, x, y + 22, length, SEPARATOR_EDGE, SEPARATOR_CENTER);
        GraphicUtils.drawHLine(graphics, x + length, y + 22, 1 + length, SEPARATOR_CENTER, SEPARATOR_EDGE);
    }
}
