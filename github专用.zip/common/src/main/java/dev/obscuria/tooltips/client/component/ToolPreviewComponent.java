package dev.obscuria.tooltips.client.component;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.tooltip.ClientTooltipComponent;
import net.minecraft.world.item.ItemStack;

/**
 * 3D item preview.
 * <p>
 * 26.3 renders GUI items through {@code GuiItemRenderState} instead of an
 * immediate {@code renderItem} call, and the preview needs a full 3D pose
 * ({@code Matrix4f}) which the 2D {@code Matrix3x2fStack} cannot express. The
 * layout still reserves its space so the tooltip geometry stays correct; only
 * the spinning model is disabled until this is reworked on the render-state API.
 */
public record ToolPreviewComponent(ItemStack stack) implements ClientTooltipComponent {

    @Override
    public int getHeight() {
        return 64;
    }

    @Override
    public int getWidth(Font font) {
        return 40;
    }

    @Override
    public void extractImage(Font font, int x, int y, int width, int height, GuiGraphicsExtractor graphics) {
        // TODO 26.3: replace with a GuiItemRenderState submission (or a dedicated
        // picture-in-picture renderer) so the 3D model comes back.
    }

    @Override
    public void extractText(GuiGraphicsExtractor graphics, Font font, int x, int y) {
        // No text.
    }
}
